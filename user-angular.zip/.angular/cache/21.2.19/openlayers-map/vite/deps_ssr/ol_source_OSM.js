import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  TileImage_default,
  createXYZ,
  extentFromProjection
} from "./chunk-HAHBDAAI.js";
import "./chunk-JGNUMGWK.js";
import "./chunk-AFKR7QAX.js";
import "./chunk-2SLAAHZU.js";
import "./chunk-B2FBFPUG.js";
import "./chunk-7CO7URWO.js";
import "./chunk-Y4HYAKUG.js";
import "./chunk-AEYEFI2K.js";
import "./chunk-L2MEMU6Z.js";
import "./chunk-KUGQLXPL.js";
import "./chunk-TXYUZPOP.js";
import "./chunk-WV3J65K2.js";
import "./chunk-7ZU4XM3P.js";
import "./chunk-L5IMJCG7.js";
import "./chunk-K6EDS6IV.js";
import "./chunk-AEC7SQEE.js";
import "./chunk-2RA7XYEX.js";
import "./chunk-NBJEWB7X.js";
import "./chunk-UNKSC2SZ.js";
import "./chunk-SRZQXID3.js";
import "./chunk-KKE2KTSF.js";

// node_modules/ol/source/XYZ.js
var XYZ = class extends TileImage_default {
  /**
   * @param {Options} [options] XYZ options.
   */
  constructor(options) {
    options = options || {};
    const projection = options.projection !== void 0 ? options.projection : "EPSG:3857";
    const tileGrid = options.tileGrid !== void 0 ? options.tileGrid : createXYZ({
      extent: extentFromProjection(projection),
      maxResolution: options.maxResolution,
      maxZoom: options.maxZoom,
      minZoom: options.minZoom,
      tileSize: options.tileSize
    });
    super({
      attributions: options.attributions,
      cacheSize: options.cacheSize,
      crossOrigin: options.crossOrigin,
      referrerPolicy: options.referrerPolicy,
      interpolate: options.interpolate,
      projection,
      reprojectionErrorThreshold: options.reprojectionErrorThreshold,
      tileGrid,
      tileLoadFunction: options.tileLoadFunction,
      tilePixelRatio: options.tilePixelRatio,
      tileUrlFunction: options.tileUrlFunction,
      url: options.url,
      urls: options.urls,
      wrapX: options.wrapX !== void 0 ? options.wrapX : true,
      transition: options.transition,
      attributionsCollapsible: options.attributionsCollapsible,
      zDirection: options.zDirection
    });
    this.gutter_ = options.gutter !== void 0 ? options.gutter : 0;
  }
  /**
   * @return {number} Gutter.
   * @override
   */
  getGutter() {
    return this.gutter_;
  }
};
var XYZ_default = XYZ;

// node_modules/ol/source/OSM.js
var ATTRIBUTION = '&#169; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors.';
var OSM = class extends XYZ_default {
  /**
   * @param {Options} [options] Open Street Map options.
   */
  constructor(options) {
    options = options || {};
    let attributions;
    if (options.attributions !== void 0) {
      attributions = options.attributions;
    } else {
      attributions = [ATTRIBUTION];
    }
    const url = options.url !== void 0 ? options.url : "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
    super({
      attributions,
      attributionsCollapsible: false,
      cacheSize: options.cacheSize,
      crossOrigin: options.crossOrigin !== void 0 ? options.crossOrigin : "anonymous",
      referrerPolicy: options.referrerPolicy || "origin-when-cross-origin",
      interpolate: options.interpolate,
      maxZoom: options.maxZoom !== void 0 ? options.maxZoom : 19,
      reprojectionErrorThreshold: options.reprojectionErrorThreshold,
      tileLoadFunction: options.tileLoadFunction,
      transition: options.transition,
      url,
      wrapX: options.wrapX,
      zDirection: options.zDirection
    });
  }
};
var OSM_default = OSM;
export {
  ATTRIBUTION,
  OSM_default as default
};
//# sourceMappingURL=ol_source_OSM.js.map
