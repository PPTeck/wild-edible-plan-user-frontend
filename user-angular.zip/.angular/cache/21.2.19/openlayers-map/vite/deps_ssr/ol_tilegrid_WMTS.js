import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  WMTS_default,
  createFromCapabilitiesMatrixSet
} from "./chunk-WV3J65K2.js";
import "./chunk-7ZU4XM3P.js";
import "./chunk-L5IMJCG7.js";
import "./chunk-K6EDS6IV.js";
import "./chunk-AEC7SQEE.js";
import "./chunk-2RA7XYEX.js";
import "./chunk-NBJEWB7X.js";
import "./chunk-UNKSC2SZ.js";
import "./chunk-SRZQXID3.js";
import "./chunk-KKE2KTSF.js";
export {
  createFromCapabilitiesMatrixSet,
  WMTS_default as default
};
