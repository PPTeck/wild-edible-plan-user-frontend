import { createRequire } from 'module';const require = createRequire(import.meta.url);

// node_modules/ol/tilegrid/common.js
var DEFAULT_MAX_ZOOM = 42;
var DEFAULT_TILE_SIZE = 256;

export {
  DEFAULT_MAX_ZOOM,
  DEFAULT_TILE_SIZE
};
//# sourceMappingURL=chunk-K6EDS6IV.js.map
