import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  AngularAppEngine,
  IS_DISCOVERING_ROUTES,
  InlineCriticalCssProcessor,
  PrerenderFallback,
  RenderMode,
  createRequestHandler,
  destroyAngularServerApp,
  extractRoutesAndCreateRouteTree,
  getOrCreateAngularServerApp,
  getRoutesFromAngularRouterConfig,
  provideServerRendering,
  setAngularAppEngineManifest,
  setAngularAppManifest,
  withAppShell,
  withRoutes
} from "./chunk-TEK6MYNX.js";
import "./chunk-7VO7PY3Q.js";
import "./chunk-KETKS4UF.js";
import "./chunk-UK6LFLMW.js";
import "./chunk-6YKLXSH3.js";
import "./chunk-XNSHGSAB.js";
import "./chunk-76E3NMX7.js";
import "./chunk-FUKOPTSL.js";
import "./chunk-C3HGQGGB.js";
import "./chunk-BEB7TLIX.js";
import "./chunk-C5KMYEKS.js";
import "./chunk-KKE2KTSF.js";
export {
  AngularAppEngine,
  IS_DISCOVERING_ROUTES,
  PrerenderFallback,
  RenderMode,
  createRequestHandler,
  provideServerRendering,
  withAppShell,
  withRoutes,
  InlineCriticalCssProcessor as ɵInlineCriticalCssProcessor,
  destroyAngularServerApp as ɵdestroyAngularServerApp,
  extractRoutesAndCreateRouteTree as ɵextractRoutesAndCreateRouteTree,
  getOrCreateAngularServerApp as ɵgetOrCreateAngularServerApp,
  getRoutesFromAngularRouterConfig as ɵgetRoutesFromAngularRouterConfig,
  setAngularAppEngineManifest as ɵsetAngularAppEngineManifest,
  setAngularAppManifest as ɵsetAngularAppManifest
};
