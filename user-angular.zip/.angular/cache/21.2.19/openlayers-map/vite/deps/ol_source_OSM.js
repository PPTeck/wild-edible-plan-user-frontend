import {
  TileImage_default,
  createXYZ,
  extentFromProjection
} from "./chunk-ZIFJSGJB.js";
import "./chunk-BHG3LBTB.js";
import "./chunk-KP2C6MLN.js";
import "./chunk-6AOD5RZD.js";
import "./chunk-R3IZXNOD.js";
import "./chunk-3U7ETZD3.js";
import "./chunk-SDSJKRCC.js";
import "./chunk-LKCQU6NL.js";
import "./chunk-6NHAKJI5.js";
import "./chunk-7XLDRUOU.js";
import "./chunk-UXZF7EKT.js";
import "./chunk-MFOE5BIL.js";
import "./chunk-MCVZ7ETQ.js";
import "./chunk-RTI4UI2V.js";
import "./chunk-QQCNHA7Q.js";
import "./chunk-P3G6H5S3.js";
import "./chunk-5EB35IQO.js";
import "./chunk-7Y62HV65.js";
import "./chunk-HXESKFRR.js";
import "./chunk-3LKLLODD.js";
import "./chunk-7PLCLRNK.js";

// node_modules/ol/source/XYZ.js
var XYZ = class extends TileImage_default {
  /**
   * @param {Options} [options] XYZ options.
   */
  constructor(options) {
    options = options || {};
    const projection = options.projection !== void 0 ? options.projection : "EPSG:3857";
    const tileGrid = options.tileGrid !== void 0 ? options.tileGrid : createXYZ({
      extent: extentFromProjection(projection),
      maxResolution: options.maxResolution,
      maxZoom: options.maxZoom,
      minZoom: options.minZoom,
      tileSize: options.tileSize
    });
    super({
      attributions: options.attributions,
      cacheSize: options.cacheSize,
      crossOrigin: options.crossOrigin,
      referrerPolicy: options.referrerPolicy,
      interpolate: options.interpolate,
      projection,
      reprojectionErrorThreshold: options.reprojectionErrorThreshold,
      tileGrid,
      tileLoadFunction: options.tileLoadFunction,
      tilePixelRatio: options.tilePixelRatio,
      tileUrlFunction: options.tileUrlFunction,
      url: options.url,
      urls: options.urls,
      wrapX: options.wrapX !== void 0 ? options.wrapX : true,
      transition: options.transition,
      attributionsCollapsible: options.attributionsCollapsible,
      zDirection: options.zDirection
    });
    this.gutter_ = options.gutter !== void 0 ? options.gutter : 0;
  }
  /**
   * @return {number} Gutter.
   * @override
   */
  getGutter() {
    return this.gutter_;
  }
};
var XYZ_default = XYZ;

// node_modules/ol/source/OSM.js
var ATTRIBUTION = '&#169; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors.';
var OSM = class extends XYZ_default {
  /**
   * @param {Options} [options] Open Street Map options.
   */
  constructor(options) {
    options = options || {};
    let attributions;
    if (options.attributions !== void 0) {
      attributions = options.attributions;
    } else {
      attributions = [ATTRIBUTION];
    }
    const url = options.url !== void 0 ? options.url : "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
    super({
      attributions,
      attributionsCollapsible: false,
      cacheSize: options.cacheSize,
      crossOrigin: options.crossOrigin !== void 0 ? options.crossOrigin : "anonymous",
      referrerPolicy: options.referrerPolicy || "origin-when-cross-origin",
      interpolate: options.interpolate,
      maxZoom: options.maxZoom !== void 0 ? options.maxZoom : 19,
      reprojectionErrorThreshold: options.reprojectionErrorThreshold,
      tileLoadFunction: options.tileLoadFunction,
      transition: options.transition,
      url,
      wrapX: options.wrapX,
      zDirection: options.zDirection
    });
  }
};
var OSM_default = OSM;
export {
  ATTRIBUTION,
  OSM_default as default
};
//# sourceMappingURL=ol_source_OSM.js.map
