// node_modules/ol/has.js
var ua = typeof navigator !== "undefined" && typeof navigator.userAgent !== "undefined" ? navigator.userAgent.toLowerCase() : "";
var SAFARI = ua.includes("safari") && !ua.includes("chrom");
var SAFARI_BUG_237906 = SAFARI && (ua.includes("version/15.4") || /cpu (os|iphone os) 15_4 like mac os x/.test(ua));
var WEBKIT = ua.includes("webkit") && !ua.includes("edge");
var MAC = ua.includes("macintosh");
var DEVICE_PIXEL_RATIO = typeof devicePixelRatio !== "undefined" ? devicePixelRatio : 1;
var WORKER_OFFSCREEN_CANVAS = typeof WorkerGlobalScope !== "undefined" && typeof OffscreenCanvas !== "undefined" && self instanceof WorkerGlobalScope;
var IMAGE_DECODE = typeof Image !== "undefined" && Image.prototype.decode;
var CREATE_IMAGE_BITMAP = typeof createImageBitmap === "function";
var PASSIVE_EVENT_LISTENERS = (function() {
  let passive = false;
  try {
    const options = Object.defineProperty({}, "passive", {
      get: function() {
        passive = true;
      }
    });
    window.addEventListener("_", null, options);
    window.removeEventListener("_", null, options);
  } catch {
  }
  return passive;
})();

// node_modules/ol/dom.js
function createCanvasContext2D(width, height, canvasPool, settings) {
  let canvas;
  if (canvasPool && canvasPool.length) {
    canvas = /** @type {HTMLCanvasElement} */
    canvasPool.shift();
  } else if (WORKER_OFFSCREEN_CANVAS) {
    canvas = new class extends OffscreenCanvas {
      style = {};
    }(width ?? 300, height ?? 150);
  } else {
    canvas = document.createElement("canvas");
  }
  if (width) {
    canvas.width = width;
  }
  if (height) {
    canvas.height = height;
  }
  return (
    /** @type {CanvasRenderingContext2D|OffscreenCanvasRenderingContext2D} */
    canvas.getContext("2d", settings)
  );
}
var sharedCanvasContext;
function getSharedCanvasContext2D() {
  if (!sharedCanvasContext) {
    sharedCanvasContext = createCanvasContext2D(1, 1);
  }
  return sharedCanvasContext;
}
function releaseCanvas(context) {
  const canvas = context.canvas;
  canvas.width = 1;
  canvas.height = 1;
  context.clearRect(0, 0, 1, 1);
}
function outerWidth(element) {
  let width = element.offsetWidth;
  const style = getComputedStyle(element);
  width += parseInt(style.marginLeft, 10) + parseInt(style.marginRight, 10);
  return width;
}
function outerHeight(element) {
  let height = element.offsetHeight;
  const style = getComputedStyle(element);
  height += parseInt(style.marginTop, 10) + parseInt(style.marginBottom, 10);
  return height;
}
function replaceNode(newNode, oldNode) {
  const parent = oldNode.parentNode;
  if (parent) {
    parent.replaceChild(newNode, oldNode);
  }
}
function removeChildren(node) {
  while (node.lastChild) {
    node.lastChild.remove();
  }
}
function replaceChildren(node, children) {
  const oldChildren = node.childNodes;
  for (let i = 0; true; ++i) {
    const oldChild = oldChildren[i];
    const newChild = children[i];
    if (!oldChild && !newChild) {
      break;
    }
    if (oldChild === newChild) {
      continue;
    }
    if (!oldChild) {
      node.appendChild(newChild);
      continue;
    }
    if (!newChild) {
      node.removeChild(oldChild);
      --i;
      continue;
    }
    node.insertBefore(newChild, oldChild);
  }
}
function createMockDiv() {
  const mockedDiv = new Proxy(
    {
      /**
       * @type {Array<HTMLElement>}
       */
      childNodes: [],
      /**
       * @param {HTMLElement} node html node.
       * @return {HTMLElement} html node.
       */
      appendChild: function(node) {
        this.childNodes.push(node);
        return node;
      },
      /**
       * dummy function, as this structure is not supposed to have a parent.
       */
      remove: function() {
      },
      /**
       * @param {HTMLElement} node html node.
       * @return {HTMLElement} html node.
       */
      removeChild: function(node) {
        const index = this.childNodes.indexOf(node);
        if (index === -1) {
          throw new Error("Node to remove was not found");
        }
        this.childNodes.splice(index, 1);
        return node;
      },
      /**
       * @param {HTMLElement} newNode new html node.
       * @param {HTMLElement} referenceNode reference html node.
       * @return {HTMLElement} new html node.
       */
      insertBefore: function(newNode, referenceNode) {
        const index = this.childNodes.indexOf(referenceNode);
        if (index === -1) {
          throw new Error("Reference node not found");
        }
        this.childNodes.splice(index, 0, newNode);
        return newNode;
      },
      style: {}
    },
    {
      get(target, prop, receiver) {
        if (prop === "firstElementChild") {
          return target.childNodes.length > 0 ? target.childNodes[0] : null;
        }
        return Reflect.get(target, prop, receiver);
      }
    }
  );
  return (
    /** @type {HTMLDivElement} */
    /** @type {*} */
    mockedDiv
  );
}
function isCanvas(obj) {
  return typeof HTMLCanvasElement !== "undefined" && obj instanceof HTMLCanvasElement || typeof OffscreenCanvas !== "undefined" && obj instanceof OffscreenCanvas;
}

// node_modules/ol/ImageState.js
var ImageState_default = {
  IDLE: 0,
  LOADING: 1,
  LOADED: 2,
  ERROR: 3,
  EMPTY: 4
};

export {
  ImageState_default,
  WEBKIT,
  MAC,
  DEVICE_PIXEL_RATIO,
  WORKER_OFFSCREEN_CANVAS,
  IMAGE_DECODE,
  CREATE_IMAGE_BITMAP,
  PASSIVE_EVENT_LISTENERS,
  createCanvasContext2D,
  getSharedCanvasContext2D,
  releaseCanvas,
  outerWidth,
  outerHeight,
  replaceNode,
  removeChildren,
  replaceChildren,
  createMockDiv,
  isCanvas
};
//# sourceMappingURL=chunk-LKCQU6NL.js.map
